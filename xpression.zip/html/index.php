<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
    		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
		<meta name="author" content="Xpression">
		<meta name="description" http-equiv="description" content="Xpression 2018 | April , 2018 | Xpression  - An Annual Youth Programme organised by ISKCON Kanpur aimed at De-addiction programme through the process of vedic cultural nourishment" />
		
       
        <meta property="og:description" content="Xpression 2018 | April , 2018 | Xpression  - An Annual Youth Programme organised by ISKCON Kanpur aimed at De-addiction programme through the process of vedic cultural nourishment."/>
		
    <!-- Loading Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    
    <!-- Loading Font Icons -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <!-- Include all css plugins (below), or include individual files as needed -->
    <link href="assets/css/flickity.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/magnific-popup.css" rel="stylesheet" type="text/css">
    
    <!-- Main CSS -->
    <link href="assets/css/dione_main.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/dione_style.css" rel="stylesheet" type="text/css">
	
	<!-- CSS -->
	<link rel="stylesheet" href="css/vendors/bootstrap.min.css">
	<!-- Font icons -->
	<link rel="stylesheet" href="css/vendors/fontello.css" >
	<!--[if IE 7]>
	<link rel="stylesheet" href="css/fontello-ie7.css" ><![endif]-->
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="js/vendors/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="js/vendors/owl-carousel/owl.theme.css">
	<!-- fancybox.js -->
	<link rel="stylesheet" href="js/vendors/fancybox/jquery.fancybox.css" />
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/vendors/animate.css">
	<!-- Custom CSS -->
	<link rel="stylesheet" href="css/styles.css" />
	<!-- Custom Media-Queties -->
	<link rel="stylesheet" href="css/media-queries.css" />
    
    <!-- Color Skins CSS -->
    <link href="assets/css/dione_color_green.css" rel="stylesheet" type="text/css">
    <link href="assets/css/switch-style.css" rel="stylesheet" type="text/css">
    
    <!-- Modernizr JS for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 8]>
    <script src="assets/js/modernizr.min.js"></script>
    <![endif]-->


</head>

<body id="page-top">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.12';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>


    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    

    
    
    <!-- Navigation Start -->
    
    
    

    
    <!-- Section - Home Start -->
    <section id="home-bg-slider" class="bg-gray-dark-2 height-100 no-padding overflow-hidden width-100">
        <!-- BG Slider -->
        <div class="bg-slider-wrapper carousel carousel-fullscreen" data-pagedots="true">
            <div class="bg-cover bg-overlay-black-6 display-block height-100 width-100">
                <div class="display-table height-100 position-absolute position-top position-left width-100">
			
                    <div class="display-table-cell vertical-align-middle">                      
			<div class="container">  
                            <div class="row">
                                <div class="col-md-8 col-md-offset-2 text-center">
                                    <h3 class="display-block font-family-alt font-weight-700 letter-spacing-2 text-uppercase text-white xs-title-extra-large sm-title-extra-large-3 title-extra-large-5">
                                       XPRESSION 2018 
                                    </h3>
				<p class="font-family-alt letter-spacing-1 margin-3 no-margin-bottom no-margin-rl text-gray-light xs-text-large text-extra-large text-uppercase">YEAR’S MOST AWAITED YOUTH FEST</p>	
                                    <p class="font-family-alt letter-spacing-1 margin-3 no-margin-bottom no-margin-rl text-gray-light xs-text-large text-extra-large text-uppercase">
                                        THE EVE FOR JOYFUL YOUTHS <br>
					
					<b>April 14, 2018<br>
					5:00PM - 10:00PM<br>
					@<a href="1.jpg" >ISKCON KANPUR Campus(Click to download map)</a><br></b>
					
<br>
                                    </p>

                                    <a class="btn btn-home" href="#pricing"><i class="icon-star"></i>Get tickets!</a><a class="btn btn-home" href="#schedule"><i class="icon-star"></i>Schedule</a>
					<a class="btn btn-home show-video" href="faq.html" data-target="#video-modal"><i class="icon-eye"></i>FAQ</a>
                                </div>
                                <!-- //.col-md-8 -->
                            </div>
                            <!-- //.row -->
                        </div>
                        <!-- //.container -->
                    </div>
                    <!-- //.display-table-cell -->
                </div>
                <!-- //.display-table -->
            </div>
            <!-- //.bg-cover -->
            
            <div class="bg-cover bg-overlay-black-6 display-block height-100 width-100">
                <div class="display-table height-100 position-absolute position-top position-left width-100">
                    <div class="display-table-cell vertical-align-middle">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8 col-md-offset-2 text-center">
                                    <h3 class="display-block font-family-alt font-weight-500 letter-spacing-2 text-uppercase text-white xs-title-extra-large sm-title-extra-large-3 title-extra-large-5">
                                      THE BIGGEST YOUTH FEST OF THE YEAR
                                    </h3>
<p class="font-family-alt letter-spacing-1 margin-3 no-margin-bottom no-margin-rl text-gray-light xs-text-large text-extra-large text-uppercase">
                                        OVER 10,000+ YOUTHS. BOOK YOUR PLACE NOW.                                 
</p>
                                    <p class="font-family-alt letter-spacing-1 margin-3 no-margin-bottom no-margin-rl text-gray-light xs-text-large text-extra-large text-uppercase">
                                 
			<br><b>April 14, 2018<br>
					5:00PM - 10:00PM<br>
					@<a href="1.jpg" >ISKCON KANPUR Campus(Click to download map)</a><br></b>	
</p>

                                  <a class="btn btn-home" href="#pricing"><i class="icon-star"></i>Get tickets!</a><a class="btn btn-home" href="#schedule"><i class="icon-star"></i>Schedule</a>
					<a class="btn btn-home show-video" href="faq.html" data-target="#video-modal"><i class="icon-eye"></i>FAQ</a>                       </div>
                                <!-- //.col-md-8 -->
                            </div>
                            <!-- //.row -->
                        </div>
                        <!-- //.container -->
                    </div>
                    <!-- //.display-table-cell -->
                </div>
                <!-- //.display-table -->
            </div>
            <!-- //.bg-cover -->
            
            <div class="bg-cover bg-overlay-black-6 display-block height-100 width-100">
                <div class="display-table height-100 position-absolute position-top position-left width-100">
                    <div class="display-table-cell vertical-align-middle">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8 col-md-offset-2 text-center">
                                    <h2 class="display-block font-family-alt font-weight-500 letter-spacing-2 text-uppercase text-white xs-title-extra-large sm-title-extra-large-3 title-extra-large-5">
                                        DON’T MISS IT !<br>
GRAB YOUR CHANCE !
                                    </h2>

                                    <p class="font-family-alt letter-spacing-1 margin-3 no-margin-bottom no-margin-rl text-gray-light xs-text-large text-extra-large text-uppercase">
                                        ENTERTAINMENT that will EMPOWER you to EXCEED
			<br><b>April 14, 2018<br>
					5:00PM - 10:00PM<br>
					@<a href="1.jpg" >ISKCON KANPUR Campus(Click to download map)</a><br></b>	
                                    </p>

                                   <a class="btn btn-home" href="#pricing"><i class="icon-star"></i>Get tickets!</a><a class="btn btn-home" href="#schedule"><i class="icon-star"></i>Schedule</a>
					<a class="btn btn-home show-video" href="faq.html" data-target="#video-modal"><i class="icon-eye"></i>FAQ</a>
                                </div>
                                <!-- //.col-md-8 -->
                            </div>
                            <!-- //.row -->
                        </div>
                        <!-- //.container -->
                    </div>
                    <!-- //.display-table-cell -->
                </div>
                <!-- //.display-table -->

            </div>
            <!-- //.bg-cover -->
        </div>
        <!-- //.bg-slider-wrapper -->
    </section>
    <!-- //Section - Home End -->
    

		
<!--fb modal-->

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Registration Open.Hare Krishna
<br>Even storm cannot stop us.
So we are back on this Saturday, 14 April,2018. 
Same performers, same celebrities, free buses, free dinner.
<br>SAME PASSES WILL BE VALID.
<br>Timings - 5 to 9 PM
<br>For any queries pls call us on 88530 48745
Thanks.</h4>
        </div>
        <!--<div class="modal-body">
          <p> <a class="btn btn-home" href="faq.html"><i class="icon-star"></i>Program FAQs</a> 
<a class="btn btn-home" type=button  href="#schedule" id="tbutton" ><i class="icon-star"></i>Event Schedule</a>
<a class="btn btn-home" type=button  href="faq.html" id="tbutton" ><i class="icon-star"></i>Free Bus Facility</a> 
<a class="btn btn-home" type=button  href="1.jpg" id="tbutton" ><i class="icon-star"></i>ISKCON CAMPUS MAP</a>
</p>-->

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<!--fb modal ends -->
    
    <!-- Intro Start -->
    <div id="intro" class="bg-white overflow-hidden position-relative width-100">
        <div class="container-fluid no-padding">
            <div class="row no-padding-rl xs-padding-6 padding-4">
                <div class="col-md-12 text-center">
                    <span class="display-block font-family-alt letter-spacing-1 text-gray-dark-2 text-medium text-uppercase">XCEL your XPECTATIONs with XPRESSION ‘18</span>
                    <span class="display-block font-family-alt font-weight-700 letter-spacing-2 margin-1 no-margin-bottom text-gray-dark-2 text-uppercase xs-text-extra-large title-large">ENTERTAINMENT. INSPIRATION. EMPOWERMENT.</span>
                </div>
                <!-- //.col-md-12 -->
            </div>
            <!-- //.row -->
            
            <div class="row">
                <!-- Features Box Style v1 Start -->
                <div class="features-box col-md-4 no-padding text-center">
                    <div class="bg-cover bg-overlay-black-4 overflow-hidden position-relative">
                        <div class="height-100 position-absolute position-top position-left width-100">
                            <div class="display-table height-100 width-100">
                                <div class="display-table-cell text-center vertical-align-middle">
                                    <span class="display-block font-family-alt letter-spacing-2 text-medium text-uppercase text-white"><b>World Class Performers</b></span>
                                </div>
                                <!-- //.display-table-cell -->
                            </div>
                            <!-- //.display-table -->
                        </div>
                        <!-- //.height-100 -->
                    </div>
                    <!-- //.bg-cover -->
                </div>
                <!-- //Features Box Style v1 End -->
                
                <!-- Features Box Style v1 Start -->
                <div class="features-box col-md-4 no-padding text-center">
                    <div class="bg-cover bg-overlay-black-4 overflow-hidden position-relative">
                        <div class="height-100 position-absolute position-top position-left width-100">
                            <div class="display-table height-100 width-100">
                                <div class="display-table-cell text-center vertical-align-middle">
                                    <span class="display-block font-family-alt letter-spacing-2 text-medium text-uppercase text-white"><b>SUCCESS SUTRAS <br>by Most Successful<br> Entrepreneurs and Leaders</b></span>
                                </div>
                                <!-- //.display-table-cell -->
                            </div>
                            <!-- //.display-table -->
                        </div>
                        <!-- //.height-100 -->
                    </div>
                    <!-- //.bg-cover -->
                </div>
                <!-- //Features Box Style v1 End -->
                
                <!-- Features Box Style v1 Start -->
                <div class="features-box col-md-4 no-padding text-center">
                    <div class="bg-cover bg-overlay-black-4 overflow-hidden position-relative">
                        <div class="height-100 position-absolute position-top position-left width-100">
                            <div class="display-table height-100 width-100">
                                <div class="display-table-cell text-center vertical-align-middle">
                                    <span class="display-block font-family-alt letter-spacing-2 text-medium text-uppercase text-white"><b>World’s Best <br>Motivational Speakers</b></span>
                                </div>
                                <!-- //.display-table-cell -->
                            </div>
                            <!-- //.display-table -->
                        </div>
                        <!-- //.height-100 -->
                    </div>
                    <!-- //.bg-cover -->
                </div>
                <!-- //Features Box Style v1 End -->
            </div>
            <!-- //.row -->
            
            <!-- //.row -->
        </div>
        <!-- //.container-fluid -->
    </div>
    <!-- //Intro End -->
    


<nav id="navigation" class="navbar navbar-fixed-top navbar-white">
        <div class="container">
            <div class="row">
                <div class="navbar-header col-md-3">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-dione">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                   <!-- <a class="navbar-brand page-scroll font-family-alt letter-spacing-1 text-extra-large text-uppercase" href="#page-top">
                        <img class="logo-navbar-dark" src="assets/images/xpression.png" alt=""/>
                        <img class="logo-navbar-white" src="assets/images/xpression.png" alt=""/>
                    </a>-->
			
                </div>
                <!-- //.navbar-header -->
                
                <div id="navbar-dione" class="navbar-collapse collapse col-md-9 pull-right navbar-white">
                    <ul class="nav navbar-nav font-family-alt letter-spacing-1 text-uppercase">
			<li><img src="assets/images/xpression.png" align="left" class= "img-responsive" ></li>
                        <li><a href="#about" class="page-scroll">About</a></li>
                        <li><a href="#speakers" class="page-scroll">Speakers</a></li>
                        <li><a href="#performances" class="page-scroll">Performances</a></li>
                        <li><a href="#gallery" class="page-scroll">Gallery</a></li>			
                 	 <li><a href="#contact" class="page-scroll">Contact</a></li>
			<!-- <li><a href="#schedule" class="page-scroll">Schedule</a></li>-->
			<a class="btn"  data-toggle="modal" data-target="#modal" align="right"><i class="icon-star"></i>Registration</a> 
                    </ul>
			
                </div>
                <!-- //.navbar-collapse -->
            </div>
            <!-- //.row -->
        </div>
        <!-- //.container -->
   </nav>
    <!-- //Navigation End -->   
    
    <!-- Section - About Start -->
    <section id="about" class="bg-white-2">
        <div class="container">
            <div class="row no-padding-rl no-padding-top padding-8">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <h3 class="font-family-alt font-weight-700 letter-spacing-2 text-uppercase xs-title-small title-medium title-sideline-base-color">About This Event</h3>
                </div>
                <!-- //.col-md-8 -->
            </div>
            <!-- //.row -->
            
            <div class="row">
                <div class="col-md-5 xs-text-center">
                  
                    <p class="margin-5-5 no-margin-bottom no-margin-rl text-large text-gray-dark-2">Xpression is a Mega Youth Programme by ISKCON Kanpur to Empower to the Youths for Achieving High Character, Determination and Goal.
Xpression is a clarion call to the Youths to rise to their full potential as the world class leaders by Equipping them with Values to overcome SelfDestructive Habits and Facilitating their OverAll Personality Development through Music, Drama and Motivational Talks. We’re Bringing 10,000+ youths together for a positive transformation.
If you have the inner passion to change the face of the World for the <strike>better</strike> best, JOIN US…
<ul>
								<li class="tick"><i class="fa fa-check-circle" ></i> Motivational Talks</li>
								<li class="tick"><i class="fa fa-check-circle" ></i> Performances</li>
								<li class="tick"><i class="fa fa-check-circle" ></i> Dramas</li>
					
								
							</ul>




</p> </div>
<iframe width="560" height="315" src="https://www.youtube.com/embed/FX9zIfcdIHI?ecver=2" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                  
               
                <!-- //.col-md-5 -->
				<div class="col-md-6">
						<div class="about-slider">
							<div id="owl-demo" class="owl-carousel owl-theme">
								<iframe width="560" height="315" src="https://www.youtube.com/embed/w8-Mn-0Susc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
							</div>
						</div>
					</div>
            </div>
            <!-- //.row -->
        </div>
        <!-- //.container -->
    </section>
    <!-- //Section - About End -->
    
<!-- begin Speakers -->
	<section class="speakers" id="speakers">
		<h2>The Speakers</h2>
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
				<div class="item active">
					<figure class="speakers-item">
						<img src="img/speakers/speaker1.png" alt="//">
						<div class="txt">
							<h3>HH Gopal Krishna Goswami</h3>
							<h5>Governing Body Commissioner & Spiritual Master in ISKCON</h5>						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<p>A Living Testimony of Selfless Service to Humanity and the World from last 50 Years, HH Gopal Krishna Goswami is one of those who have transformed ISKCON to one of the largest Spiritual Educational Societies in the World Today with over 750 centres Worldwide. 
</p>
							
						</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/speaker2.jpeg" alt="//">
						<div class="txt">
							<h3>Devakinandan Das</h3>
							<h5>Zonal Secretary, ISKCON <br> Speaker Atma series Colors TV</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<p>A Worldwide Renowned Speaker HG Devakinandan Das is known for his practical tips and techniques on People Management, Resource Management and Leadership based on Eternal Principles from Wisdom Literatures. 
It’s a great inspiration to hear from him about Dedication to Goal, Determination in Endeavours and Faith in oneself and the Supreme. 
</p>						
						</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/speaker3.jpeg" alt="//">
						<div class="txt">
							<h3>Gauranga Das</h3>
							<h5>World Renowned Motivational Speaker
Awarded by United Nations</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<p>Mr. Gauranga Das, An IIT Mumbai graduate is one the most popular Motivational Speakers and Life Coach. Inspiring thousands of Corporates, Educators, Leaders and Youths through across the globe in institutes like MIT, Stanford. - he's a regular speaker at TEDx. He has recieved Winner United Nations Award for Sustainable Tourism, 2017</p>
						</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/speaker4.jpg" alt="//">
						<div class="txt">
							<h3>Mr. B. K. Goenka</h3>
							<h5>Chairman, Welspun Group</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<p>A true success story Mr. Goenka is the Founder of Welspun Group which is now one of the Largest Home Textiles producer in the World and World's second largest manufacturer of large diameter pipes.
Among 100 richest Indians, Mr. Goenka is also the Co-Chair of CII National Committee on Textiles
He will share Sutras for Success.</p>
						</div>
					</figure>
				</div>
			</div>

	</section>
	<!-- end Speakers -->


<script>
var modal = document.getElementById('tbutton');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

</script>

<!-- modal -->
  <div class="modal fade" id="modal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Registration closed.Due to severe rain and storm, Program is rescheduled on next Saturday April 14,2018 with same performances, program and same pass.</h4>
        </div>
        <div class="modal-body">
          <p> <a class="btn btn-home" href="register.html"><i class="icon-star"></i>I had already purchased the ticket want to activate 
it.</a> 
<a class="btn btn-home" type=button  href="#pricing" id="tbutton" ><i class="icon-star"></i>Get Tickets</a> 
</p>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<!--modal ends -->
    
      <!-- begin Speakers -->
	<section class="speakers" id="performances">
		<h2>The Performances</h2>
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
				<div class="item active">
					<figure class="speakers-item">
						<img src="img/speakers/11.jpg" alt="//">
						<div class="txt">
							<h3>MUSIC PERFORMANCE</h3>
							<h5>Enchanters Band<br>Russia</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<h3>MUSIC PERFORMANCE</h3>
							<h5>Enchanters Band <br>
Russia</h5>
							<p>The energetic Rock Band from Russia to fill the gathering with storm of happiness and joy. </p>
						</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/prince.jpg" alt="//">
						<div class="txt">
							<h3>Prince Dance Group</h3>
							<h5>Winners, India’s Got Talent, S1</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<h3>Prince Dance Group</h3>
							<h5>Winners, India’s Got Talent, S1</h5>
							<p>This group of World Class performers and Winners of IGT – India’s Biggest Talent Hunt Shows are a group of construction site workers from Orissa. Their unique formation based Dance depicting various famous pastimes of Devotion have won the hearts of millions across the Globe.</p>
							</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/speaker9.jpg" alt="//">
						<div class="txt">
							<h3>Peer-Pressue <br> Anti-Addiction Drama</h3>
							<h5>IIT BHU</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<h3>Anti-Addiction Drama</h3>
							<h5>IIT BHU</h5>
							<p>Drama on dealing with Peer Pressure and Anti-Addiction by IIT BHU students. </p>
							</div>
					</figure>
					<figure class="speakers-item">
						<img src="img/speakers/speaker10.jpeg" alt="//">
						<div class="txt">
							<h3>Sand Arts Show</h3>
							<h5>Sarvam Patel, India’s Got Talent</h5>
						</div>
						<span class="overthumb"></span>
						<div class="icons">
							<h3>Sand Arts Show</h3>
							<h5>Sarvam Patel, India’s Got Talent</h5>
							<p>Nothing is this World is Useless. Even a Sand can be full of Art when in the hands of this man. This World Renowned Sand Artist will mesmerize you with his formations of themes with Sand Art.</p>
							</div>
					</figure>
				</div>
			</div>

	</section>
	<!-- end Speakers -->  
    
    <!-- Milestones Start -->
    <div id="milestones" class="bg-cover bg-overlay-black-6 no-padding-rl padding-9">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 border-right border-white xs-margin-7 xs-no-border text-center">
                    <span class="display-inline-block font-family-alt letter-spacing-2 margin-3 no-margin-bottom no-margin-rl text-extra-large text-uppercase text-white title-sideline-base-color">ISKCON Kanpur – the No. 1 Tourist Spot</span>
                    
                </div>
                <!-- //.col-sm-3 -->
                  
                <div class="col-sm-3 border-right border-white xs-margin-7 xs-no-border text-center">
                    <span class="display-inline-block font-family-alt letter-spacing-2 margin-3 no-margin-bottom no-margin-rl text-extra-large text-uppercase text-white title-sideline-base-color">Xpression – Kanpur’s Biggest Youth Fest</span>
                </div> 
                <div class="col-sm-3 border-right border-white xs-margin-7 xs-no-border text-center">
                    <span class="timer display-block font-family-alt font-weight-700 letter-spacing-1 text-white sm-title-large title-extra-large-2" data-from="0" data-to="50" data-speed="1500">100+</span>
                    <span class="display-inline-block font-family-alt letter-spacing-2 margin-3 no-margin-bottom no-margin-rl text-extra-large text-uppercase text-white title-sideline-base-color">Institutions</span>
                </div>
                <!-- //.col-sm-3 -->
                
                <div class="col-sm-3 border-right border-white xs-margin-7 xs-no-border text-center">
                    <span class="timer display-block font-family-alt font-weight-700 letter-spacing-1 text-white sm-title-large title-extra-large-2" data-from="0" data-to="10000" data-speed="1000">10,000+</span>
                    <span class="display-inline-block font-family-alt letter-spacing-2 margin-3 no-margin-bottom no-margin-rl text-extra-large text-uppercase text-white title-sideline-base-color">Youths</span>
                </div>
                <!-- //.col-sm-3 -->
             
                <!-- //.col-sm-3 -->
            </div>
            <!-- //.row -->
        </div>
        <!-- //.container -->
    </div>
    <!-- //Milestones End -->
    
   
		
	<!-- begin Testimonials
	<section class="testimonials parallax" id="testimonials" data-speed="6">
	<div class="container">
		<div id="owl-testimonials" class="owl-carousel animated" data-animation="bounceInRight" data-animation-delay="200" >
			<div class="item">
				<figure><img src="img/testimonials/person01.jpg" alt="//"></figure>
				<p>&quot;I was thrilled to see such an amazing audience. The events were extraordinary and it surely made an impact to many youths.&quot;</p>
				<div class="author clearfix">
					<i class="icon-chat"></i>
					<h5>Amish Tripathi</h5>
					<em>Writer</em>
				</div>
			</div>
			<div class="item">
				<figure><img src="img/testimonials/person02.jpg" alt="//"></figure>
				<p>&quot;I would like to give my personal congrats to the entire team of Xpression for putting up a wonderful event. The attendees were more than ecstatic than what i have ever seen anywhere else and its this spirit that puts up a favourable stage for people like us to speak / perform.&quot;</p>
				<div class="author clearfix">
					<i class="icon-chat"></i>
					<h5>Gaur Gopal Das</h5>
					<em>World Renowned Motivational Speaker</em>
				</div>
			</div>
				<div class="item">
				<figure><img src="img/testimonials/person03.jpg" alt="//"></figure>
				<p>&quot;It was a great effort by Team Xpression. Greatly appreciated the effort for this youth programme. Your hard work and efforts has lead to such successful event.&quot;</p>
				<div class="author clearfix">
					<i class="icon-chat"></i>
					<h5>Ronit Roy</h5>
					<em>Actor</em>
				</div>
			</div>
		</div>
	</div>
</section>   -->



    
  <section id="gallery" class="bg-white-3">
        <div class="container">
            <div class="row no-padding-rl no-padding-top padding-8">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <h3 class="font-family-alt font-weight-700 letter-spacing-2 text-uppercase xs-title-small title-medium title-sideline-base-color">XPRESSION'17 HIGHLIGHTS</h3>
                   
                </div>
                <!-- //.col-md-8 -->
            </div>
            <!-- //.row -->

		<div class="row">
                <div class="col-md-12">
                    <div class="gallery-wrapper">
                        <div class="gallery-grid grid-col-3 gutter-wide">
                            <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-1.jpg">
                                            <img src="assets/images/gallery-1.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				<div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-2.jpg">
                                            <img src="assets/images/gallery-2.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
                            <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-3.jpg">
                                            <img src="assets/images/gallery-3.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				<div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-4.jpg">
                                            <img src="assets/images/gallery-4.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				<div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-5.jpg">
                                            <img src="assets/images/gallery-5.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				<div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-6.jpg">
                                            <img src="assets/images/gallery-6.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				<div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-7.jpg">
                                            <img src="assets/images/gallery-7.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
                            <!-- //.item -->
                            
                            <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-8.jpg">
                                            <img src="assets/images/gallery-8.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
                            <!-- //.item -->
                            
                            <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-9.jpg">
                                            <img src="assets/images/gallery-9.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				 <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-10.jpg">
                                            <img src="assets/images/gallery-10.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				 <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-11.jpg">
                                            <img src="assets/images/gallery-11.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
				 <div class="item">
                                <figure>
                                    <div class="gallery-img">
                                        <a href="assets/images/gallery-12.jpg">
                                            <img src="assets/images/gallery-12.jpg" alt="">
                                        </a>
                                    </div>
                                    <!-- //.gallery-img -->
                                </figure>
                            </div>
			</div>
		</div>
		</div>
		</div>
	</div>
</section>
<!-- gallery finished -->

<!-- form-->

<!--end form-->
         <section class="program" id="schedule">
	<div class="container">
		<h4>See what you can do that day</h4>
		<h2>The Program</h2>


		<!-- Nav tabs -->
		<!--<a href="schedule/1.pdf" class="btn"><i class="icon-doc-text"></i>Download Schedule</a>-->
<a href= "schedule/1.pdf" align="right"><b>DOWNLOAD SCHEDULE</b></a> 		
		<ul class="nav nav-tabs animated" data-animation="flipInX" data-animation-delay="400" role="tablist">
			<li class="active"><a href="#program-day1" role="tab" data-toggle="tab">Program Day <em>April 14, 2018</em></a></li>
		</ul>

		<!-- Tab panes -->
		<div class="tab-content animated" data-animation="bounceInUp" data-animation-delay="600">
			<div class="tab-pane active" id="program-day1">
				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/11.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>5:45 – 6:10 PM</span>
					<h3>Melodious Mantra Music by Amal Kirtan (Pune)</h3>
					<p>The melodious mantra music will be performed by Amal Kirtan Party from Pune.</p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/2.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>6:10 – 6:20 PM</span>
					<h3>Welcome & Deep Prajvalan</h3>
					<p>The welcoming of guests  and program inaguration by lightning the lamp. </p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker2.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>6:20 – 6:30 PM</span>
					<h3>HG Devakinandan Das</h3>
					<p>Welcome addressing by HG Devakinandan Das</p>
				</div>

		<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/1223.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>6:30 – 6:40 PM</span>
					<h3>Dance Presentation by Anjhar Group (Welspun)</h3>
					<p>wonderful Dance performance by a group of disabled people from Gujarat named Anjhar Group.</p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker3.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>	

6:40 – 6:55 PM</span>
					<h3>HG Gauranga Prabhu, Keynote Speaker</h3>
					<p>His Grace Gauranga Das (World Renowned Motivational Speaker) will be speaking on “Role of Peer Pressure amongst the youth”</p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker9.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>6:55 – 7:20 PM</span>
					<h3>Anti-addiction Drama by IIT BHU students</h3>
					<p>Drama on dealing with Peer Pressure and Anti-Addiction by IIT BHU students.  </p>
				</div>

<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/lakhi.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>7:20 – 7:30 PM</span>
					<h3>Mr Dilip Lakhi, Guest of Honor </h3>
					<p>Motivational Speech by Mr. Dilip Lakhi.</p>
				</div>


				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/prince.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>7:30 – 7:40 PM</span>
					<h3>Ramayana Dance by Prince Dance Group</h3>
					<p>This group of World Class performers and Winners of IGT – India’s Biggest Talent Hunt Shows are a group of construction site workers from Orissa. Their unique formation based Dance depicting various famous pastimes of Devotion have won the hearts of millions across the Globe.</p>
				</div>

<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker4.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>7:40 – 8:00 PM</span>
					<h3>Mr Bal Krishna Goenka, Chief Guest</h3>
					<p>A true success story Mr. Goenka is the Founder of Welspun Group which is now one of the Largest Home Textiles producer in the World and World's second largest manufacturer of large diameter pipes. Among 100 richest Indians, Mr. Goenka is also the Co-Chair of CII National Committee on Textiles He will share Sutras for Success. </p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker10.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>8:00 – 8:15 PM</span>
					<h3>Sand Art show by Sarvam Patel, India’s Got Talent</h3>
					<p>Nothing is this World is Useless. Even a Sand can be full of Art when in the hands of this man. This World Renowned Sand Artist will mesmerize you with his formations of themes with Sand Art.</p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker1.png" alt="//">
					</figure>
					<span><i class="icon-clock"></i>8:15 – 8:20 PM</span>
					<h3>Thanksgiving by HH Gopal Krishna Goswami</h3>
					<p>Vote of Thanks by HH Gopal Krishna Goswami</p>
				</div>

				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/speaker71.jpeg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>8:20 – 9:00 PM</span>
					<h3>Kirtan by Enchanters Band, Russia</h3>
					<p>The energetic Rock Band from Russia to fill the gathering with storm of happiness and joy. </p>
				</div>
				<div class="program-tab-item clearfix">
					<figure>
						<img src="schedule/food.jpg" alt="//">
					</figure>
					<span><i class="icon-clock"></i>8:20 - 9:45 PM </span>
					<h3>Get Gifts and Dinner Prasadam</h3>
					<p>Everybody is requested to please take gifts and dinner prasadam</p>
				</div>




			</div>
	</div>
	</section>


<!-- begin Pricing -->
	<section class="pricing separator" id="pricing">
	<div class="container">
		<h4>We have a ticket for you</h4>
		<h2>Pick Your Like</h2>
		<div class="row">
		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="400">			
<div class="price"><small>Rs</small>130</div>
				<strong>I am Coming Alone. Book my Ticket NOW.</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for Youths Age 15 – 35 yrs</p>
				<a href="/checkout.php?type=1" class="btn-pricing"><span data-hover="Buy Ticket">Buy Ticket</span></a>
			<!--<button id="rzp-button1">Pay</button>-->
			</div>
		</div>

		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="800">
				
				
				<div class="price"><small>Rs</small>555</div>
				<strong>I and my Friends. We’ll Book Place for 5.</strong>
				<p>Entry Ticket. Free Transportation* Snacks Gift for Youths Age 15 – 35 yrs.</p>
				<a href="/checkout.php?type=2" class="btn-pricing"><span data-hover="Buy Ticket">Buy Ticket</span></a>
			</div>
		</div>

		
		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="800">
				<!--<p font-weight=60%><strong><strike>Original Price: Rs 750</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>-->				
				<div class="price"><small>Rs</small>650</div>
				<strong>Family Time. Family Tickets. Special Front Seats for Family. </strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Family of 3 members.</p>
				<a href="/checkout.php?type=5" class="btn-pricing"><span data-hover="Buy Ticket">Buy Ticket</span></a>
			</div>
		</div>

		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
						<!--<p font-weight=60%><strong><strike>Original Price: Rs 1000</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>	-->		
				<div class="price"><small>Rs.</small>750</div>
				<strong>Family Time. Family Tickets. Special Front Seats for Family.</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Family of 4 members.

</p>
				<a href="/checkout.php?type=6" class="btn-pricing"><span data-hover="Buy Ticket">Buy Ticket</span></a>
			</div>
		</div>

		

		<!--<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
				
								
				<div class="price"><small>Rs.</small>400</div>
				<strong>We’re Group of Friends. We’ll have 4 Tickets.</strong>
				<p>Entry Ticket. Free Transportation* Snacks Gift for Youths Age 15 – 35 yrs.</p>
				<a href="/checkout.php?type=7" class="btn-pricing"><span data-hover="Buy Ticket">SOLD OUT</span></a>
			</div>
		</div>
		</div>
		<div class="row">
		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="400">
				
							
				<div class="price"><small>Rs.</small>800</div>
				<strong>Our Gang Rocks. Give us 8 tickets.</strong>
				<p>Entry Ticket. Free Transportation* Snacks Gift for Youths Age 15 – 35 yrs.</p>
				<a href="#" class="btn-pricing"><span data-hover="Buy Ticket">SOLD OUT</span></a>

			</div>
		</div>-->

		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
						<!--<p font-weight=60%><strong><strike>Original Price: Rs 1500</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>	-->		
				<div class="price"><small>Rs.</small>1350</div>
				<strong>1 Xpression Cap + ₹ 251/- Amazon Gift Card</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Group of 15 members.

</p>
				<a href="#" class="btn-pricing"><span data-hover="SOLD OUT">SOLD OUT </span></a>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
						<!--<p font-weight=60%><strong><strike>Original Price: Rs 2500</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>-->			
				<div class="price"><small>Rs.</small>2250</div>
				<strong>1 Xpression T-Shirt + ₹ 501/- Amazon Gift Card</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Group of 25 members.

</p>
				<a href="#" class="btn-pricing"><span data-hover="SOLD OUT">SOLD OUT</span></a>
			</div>
		</div>
<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
						<!--<p font-weight=60%><strong><strike>Original Price: Rs 5000</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>-->			
				<div class="price"><small>Rs.</small>4500</div>
				<strong>1 Xpression Back Pack + ₹ 1,001/- Amazon Gift Card</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Group of 50 members.

</p>
				<a href="#" class="btn-pricing"><span data-hover="SOLD OUT">SOLD OUT</span></a>
			</div>
		</div>
<div class="col-sm-4">
			<div class="pricing-item animated" data-animation="pulse" data-animation-delay="1200">
					<!--	<p font-weight=60%><strong><strike>Original Price: Rs 10000</strike></strong></p>
				<p font-size=30px><strong>Special Discount Price: </strong></p>-->			
				<div class="price"><small>Rs.</small>9000</div>
				<strong>1 Xpression Back Pack + ₹ 2,001/- Amazon Gift Card</strong>
				<p>Entry Ticket. Free Transportation* Food and Gift for a Group of 100 members.

</p>
				<a href="#" class="btn-pricing"><span data-hover="SOLD OUT">SOLD OUT</span></a>
			</div>
		</div>
	</div></div>
	</div>
	</section>
	<!-- end Pricing -->


    
    	






    
   
    
    
    
    
    <!-- Section - Sponsors Start -->
    <section id="sponsors" class="bg-white">
        <div class="container">
            <div class="row no-padding-rl no-padding-top padding-8">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <h3 class="font-family-alt font-weight-700 letter-spacing-2 text-uppercase xs-title-small title-medium title-sideline-base-color">Sponsors</h3>
                </div>
                <!-- //.col-md-8 -->
            </div>
            <!-- //.row -->
            
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="row">
                        <div class="col-xs-6 col-sm-4 text-center">
                            <img width="200" src="assets/images/sponsor-1.jpg" alt=""/>
                        </div>
                        <!-- //.col-xs-6 -->
                        
                        <div class="col-xs-6 col-sm-4 xs-margin-3 xs-no-margin-bottom xs-no-margin-rl text-center">
                            <img width="200" src="assets/images/sponsor-2.jpg" alt=""/>
                        </div>
                        <!-- //.col-xs-6 -->
                        
                        <div class="col-xs-6 col-sm-4 xs-margin-3 xs-no-margin-bottom xs-no-margin-rl text-center">
                            <img width="200" src="assets/images/sponsor-3.jpg" alt=""/>
                        </div>
		</div>
			<div class="row">
			 <div class="col-xs-6 col-sm-4 xs-margin-3 xs-no-margin-bottom xs-no-margin-rl text-center">
                            <img width="200" src="assets/images/sponsor-4.jpg" alt=""/>
                        </div>
			<div class="col-xs-6 col-sm-4 xs-margin-3 xs-no-margin-bottom xs-no-margin-rl text-center">
                            <img width="200" src="assets/images/sponsor-5.jpeg" alt=""/>
                        </div>
			<div class="col-xs-6 col-sm-4 xs-margin-3 xs-no-margin-bottom xs-no-margin-rl text-center">
                            <img width="200" src="Ola.png" alt=""/>
                        </div>
		</div>
                        <!-- //.col-xs-6 -->
                    
                        <!-- //.col-xs-6 -->
                    </div>
                    <!-- //.row -->
                </div>
                <!-- //.col-md-10 -->
            </div>
            <!-- //.row -->
        </div>
        <!-- //.container -->
    </section>
    <!-- //Section - Sponsors End -->
    
    
    
    
    
    
    <!-- Section - Contact Start -->
    <section id="contact" class="bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
			<div class="col-md-12">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3569.788180639036!2d80.27569325022382!3d26.526936083213272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399c39d8f22f66b3%3A0x9fd821e7fd74b3f5!2sISKCON+Temple+Kanpur!5e0!3m2!1sen!2sin!4v1519569812651" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
						</div>
                    <h3 class="display-block font-weight-300 letter-spacing-1 title-large">
								<ul>
									<li>Sri Sri Radha Madhava Mandir,</li>
									<li>Mainavati Marg, Bithoor Road,Kanpur</li>
									<li>Uttar Pradesh - 208002</li>
									<li>INDIA</li></h3>
                    
                    <div class="margin-5 no-margin-bottom no-margin-rl">
                        <div class="display-inline-block margin-7 no-margin-left no-margin-tb">
                            <i class="fa fa-envelope-o display-block text-base-color xs-title-large title-extra-large-2"></i>
                            <span class="display-block margin-5 no-margin-bottom no-margin-rl text-gray-dark-2 xs-text-large title-small">regs.xpression@gmail.com</span>
                        </div>
                        <!-- //.display-inline-block -->

                        <div class="display-inline-block">
                            <i class="fa fa-phone display-block text-base-color xs-title-large title-extra-large-2"></i>
                            <span class="display-block margin-5 no-margin-bottom no-margin-rl text-gray-dark-2 xs-text-large title-small"> WhatsApp No. - +91-8853048745</span>
                        </div>
                        <!-- //.display-inline-block -->
                    </div>
                    <!-- //.margin-5 -->
                        
                    <p class="margin-5 no-margin-bottom no-margin-rl text-gray-dark-2 title-small">Give us a call or drop by anytime, we endeavour to answer all enquiries.</p>
                </div>
                <!-- //.col-md-8 -->
            </div>
            <!-- //.row -->
            
            
        </div>
        <!-- //.container -->
    </section>
    <!-- //Section - Contact End -->
    
    
    
    <!-- Footer Start -->
    <footer class="footer bg-white">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="footer-logo xs-text-center">
                        <img src="assets/images/logo-text-dark.png" alt="" class="opacity-4">
                    </div>
                    <!-- //.footer-logo -->
                </div>
                <!-- //.col-sm-4 -->
                
                <div class="col-sm-8">
                    <div class="footer-social text-right">
                        <ul class="list-inline list-unstyled no-margin xs-text-center xs-title-small title-medium">
                            <li><a href="www.facebook.com/xpression2018"><i class="fa fa-facebook"></i></a></li>
                    
                            <li><a href="www.instagram.com/xpression2018"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <!-- //.footer-social -->
                </div>
                <!-- //.col-sm-8 -->
            </div>
            <!-- //.row -->
            
            <div class="row">
                <div class="col-md-12">
                    <div class="footer-copyright text-center border-top border-gray-light">
                        <span class="font-family-alt letter-spacing-1 text-gray-dark text-small text-uppercase">&copy; 2018 Xpression. All rights reserved.</span>
                    </div>
                    <!-- //.footer-copyright -->
                </div>
                <!-- //.col-md-12 -->
            </div>
            <!-- //.row -->
        </div>
        <!-- //.container -->
    </footer>
    <!-- //Footer End -->
    
    
    <!-- Scroll to top -->
    <a href="#page-top" class="page-scroll scroll-to-top"><i class="fa fa-angle-up"></i></a>
    
    
    <!-- Loading jQuery -->
    <script src="assets/js/jquery.min.js"></script>
    
    <!-- Loading Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- Include all js plugins (below) -->
    <script src="assets/js/pace.min.js"></script>
    <script src="assets/js/debouncer.min.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.inview.min.js"></script>
    <script src="assets/js/jquery.matchHeight.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/flickity.pkgd.min.js"></script>
    <script src="assets/js/jquery.countTo.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    
    <!-- Loading Theme JS -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/switch-style.js"></script>
	
	<!-- jQuery -->
	<script src="js/vendors/jquery/jquery-1.9.1.min.js"></script>

	<!-- Respond.js media queries for IE8 -->
	<script src="js/vendors/respond.min.js"></script>

	<!-- Bootstrap-->
	<script src="js/vendors/bootstrap.min.js" ></script>

	<!-- Retina.js -->
	<script src="js/vendors/jquery/jquery.nav.js" ></script>

	<!-- One Page Scroll -->
	<script src="js/vendors/jquery/jquery.nav.js" ></script>

	<!-- Owl Carousel -->
	<script src="js/vendors/owl-carousel/owl.carousel.js"></script>

	<!-- fancybox -->
	<script src="js/vendors/fancybox/jquery.fancybox.js" ></script>

	<!-- Appear -->
	<script src="js/vendors/jquery/jquery.appear.js" ></script>

	<!-- Placeholder.js -->
	<!--[if lte IE 9]> <script src="js/vendors/placeholder.js" ></script> <script>Placeholder.init();</script> <![endif]-->

	<!-- Gmaps -->
	<script src="http://maps.google.com/maps/api/js?sensor=true" ></script>
	<script src="js/vendors/gmaps.js" ></script>

	<!-- Custom -->
	<script src="js/script.js"  ></script>
	
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
		
	<script src="checkoutform.js"></script>

<script src="lib/owl-carousel/owl.carousel.min.js"></script>
		
		<!--<script src="lib/jquery-parallax/jquery.parallax-1.1.3.js"></script>-->
        
        <!-- ScrollTo & Nav -->
		<script src="lib/jquery-one-page-nav/jquery.scrollTo.js"></script>
		<script src="lib/jquery-one-page-nav/jquery.nav.js"></script>

        <!-- Appear -->
		<script src="lib/jquery-appear/jquery.appear.js"></script>
        
        <!-- Smoothscroll -->
        <script src="js/smoothscroll.js"></script>

        <!-- Custom -->
		<script src="js/script.js"></script>
		<script src="js/custom.js"></script>

<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
<script>
  $(document).ready(function () {
     $('#tbutton').click(function (){
                window.setTimeout(function () {
                  $('#modal').modal('hide');
                }, 5000);
              });
          });
</script>



<!-- *********************** End Javascript Files *********************** -->
<!-- ******************************************************************** -->

    
</body>

</html>
