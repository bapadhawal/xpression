var options = {
    "key": "rzp_live_ARYyzEQgBdfbyq",
    "amount": "200", // 2000 paise = INR 2
    "name": "XPPRESSION 2018",
    "description": "Purchase Description",
    "image": "assets/images/xpression.png",
    "handler": function (response){
        alert(response.razorpay_payment_id);
    },
    "prefill": {
        "name": "Harshil Mathur",
	"contact": "0123456789",
        "email": "harshil@razorpay.com"
    },
    "notes": {
        "college": "ABCD"
    },
    "theme": {
        "color": "#F37254"
    }
};
var rzp1 = new Razorpay(options);

document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
