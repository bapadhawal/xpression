<?php

	//Transaction ID, name, email, contact, Institution name, amount, Ticket Type, RazorPay PaymentID
	// transaction_id, name, email, contact, institution, amount, ticket_type, razorpay_id

	$dbhost="mysql.hostinger.in";
	$dbuname="u890518127_hk";
	$dbpassword="radhamadhav";
	$dbname="u890518127_xp18";
	$con=new MySQLi($dbhost,$dbuname,$dbpassword,$dbname);
	if($con->connect_errno){
		die("Not able to connect to database".$con->connect_error);
	}

	if(!isset($_POST)){
		die("Cannot proceed to pay!");
	}
	
	$amt = $_POST['amount'];
	$name = $_POST['username'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	$institution = $_POST['institution'];
	$type = $_POST['type'];
	$how = $_POST['how'];
	
	$razorpay_id = $_POST['razorpay_payment_id'];
	
	if($amt == null || $name == null || $email == null || $contact == null){
		die("Cannot proceed to pay!");
	}
	
	$description_dict = array("1" => "Single Ticket", "2" => "Five Tickets", "3" => "Four Tickets", "4" => "Eight Tickets", "5" => "Family Time. Family Tickets.tickets for three members", "6" => "Family Time. Family Tickets. Special Front Seats for Family for four members", "7" => "Entry Ticket. Free Transportation* Food and Gift for a Family of 15 members.", "8" => "Entry Ticket. Free Transportation* Food and Gift for a Family of 25 members.", "9" => "Entry Ticket. Free Transportation* Food and Gift for a Family of 50 members.", "10" => "Entry Ticket. Free Transportation* Food and Gift for a Family of 100 members.");
	
	$amt_ac = $amt/100;
	
	$sql = "INSERT INTO registration (name, email, contact, institution, amount, ticket_type, razorpay_id,how) VALUES ('$name', '$email', '$contact', '$institution', '$amt_ac', '$type', '$razorpay_id', '$how')";
	
	$transaction_id = null;
	
	if (mysqli_query($con, $sql)) {
		$transaction_id = mysqli_insert_id($con);
	} else {
		// die("Not Allowed!");
	}
	
?>

<html>
<head>

<style>
#header{
	text-align: center;
	font-size: 48px;
}
#contents {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 60%;
    margin-left: 20%;
}

#contents td, #contents th {
    border: 1px solid;
    padding: 5px;
}

#contents tr:nth-child(even){background-color: #f2f2f2;}

#contents th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #ddd;
}
</style>

</head>
<body>

	<input type="hidden" value="<?php echo $razorpay_id; ?>" id="razorpay_id"/>
	<input type="hidden" value="<?php echo $amt; ?>" id="amount"/>
	
	<div class="receipt" id="receipt">
		<div id="header"><img src="/assets/images/xpression.png" align="left"/>Xpression 2018 Receipt</div>
		<hr>
		<br/><br/>
		<h3>This is computer generated payment reciept NOT ENTRY PASS. Please exchange this reciept to get the pass at the time of entrance.
		<div id="content">
			<table id="contents">
				<tr>
					<th>Name</th>
					<td><?php echo $name; ?></td>
				</tr>
				<tr>
					<th>Email ID</th>
					<td><?php echo $email; ?></td>
				</tr>
				<tr>
					<th>Contact Details</th>
					<td><?php echo $contact; ?></td>
				</tr>
				<tr>
					<th>Institution Name</th>
					<td><?php echo $institution; ?></td>
				</tr>
				<tr>
					<th>Date</th>
					<td><?php echo date("d-M-Y, h:i:s a");?></td>
				</tr>
				<tr>
					<th>Transaction ID</th>
					<td>#<?php echo $transaction_id; ?></td>
				</tr>
				<tr>
					<th>Payment Received</th>
					<td>Rs. <?php echo $amt/100.0; ?></td>
				</tr>
				<tr>
					<th>Ticket Description</th>
					<td><?php echo $description_dict[$type]; ?></td>
				</tr>				
			</table>
		</div>
	</div>

<div>
 <p align="center">
<button onClick="window.print()">Print this reciept</button><br>
<b>XCEL your XPECTATIONs with XPRESSION ‘18</b></p>
                   <p align="center"><b>ENTERTAINMENT. INSPIRATION. EMPOWERMENT.</b></p>
<p align="center"><b>DATE: April 7, 2018<br>
					TIME: 5:00PM - 10:00PM<br>
					VENUE: ISKCON KANPUR<br></b>
</p>
</div>
</body>

<script>
/*
$(document).ready(function(){

	var razorpay_id = document.getElementById("razorpay_id").value;
	var amount = document.getElementById("amount").value;

	var url = 'https://rzp_test_kYO2bPZrsbOoft:K4CkMmU49evCTPcDfKjaJeah@api.razorpay.com/v1/payments/pay_29QQoUBi66xm2f/capture';
	var formData = new FormData();
	formData.append("amount", amount);

	
	$.post('https://rzp_test_kYO2bPZrsbOoft:K4CkMmU49evCTPcDfKjaJeah@api.razorpay.com/v1/payments/pay_9jGV6ZPuC3l1c8/capture', function(data, status){
		alert("LOLO");
	});

	$.ajax({url: "https://rzp_test_kYO2bPZrsbOoft:K4CkMmU49evCTPcDfKjaJeah@api.razorpay.com/v1/payments/pay_9jGV6ZPuC3l1c8/capture", success: function(result){
        $("#div1").html(result);
    }});
	
	alert("Hell");
	
});
*/
</script>

<?php
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => 'https://rzp_test_kYO2bPZrsbOoft:K4CkMmU49evCTPcDfKjaJeah@api.razorpay.com/v1/payments/pay_29QQoUBi66xm2f/capture',
		CURLOPT_USERAGENT => 'Codular Sample cURL Request',
		CURLOPT_POST => 1,
		CURLOPT_POSTFIELDS => array(
		    amount => '50000',
		)
	));
?>

</html>
