<?php     
$to_email = 'dhoomdhawal@gmail.com';
$subject = 'Testing PHP Mail';
$message = 'This mail is sent using the PHP mail function';
$headers = 'From: dhoomdanger@gmail.com';
mail($to_email,$subject,$message,$headers);
?>
