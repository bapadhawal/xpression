<?php ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Xpression '17| Mega Youth Festival</title>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet" href="//blueimp.github.io/Gallery/css/blueimp-gallery.min.css">
        <link rel="stylesheet" href="css/xpression/bootstrap-image-gallery.css"
              <link rel="stylesheet" href="css/xpression/demo.css"
              <link href="css/xpression/font-awesome.min.css" rel="stylesheet">
        <link href="css/xpression/main5.css" rel="stylesheet">
        <link href="css/xpression/animate.css" rel="stylesheet">	
        <link href="css/xpression/responsive.css" rel="stylesheet">

        <!--[if lt IE 9]>
                <script src="js/html5shiv.js"></script>
                <script src="js/respond.min.js"></script>
        <![endif]-->       
        <link rel="shortcut icon" href="images/xpression/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/xpression/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/xpression/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/xpression/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/xpression/apple-touch-icon-57-precomposed.png">
    </head><!--/head-->

    <body>
        <header id="header" role="banner">		
            <div class="main-nav">
                <div class="container">
                    <div class="header-top">
                        <div class="pull-right social-icons">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-google-plus"></i></a>
                            <a href="#"><i class="fa fa-youtube"></i></a>
                        </div>
                    </div>     
                    <div class="row">	        		
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="index.php">
                                <img style="padding-top: 27px;padding-left: 15px" class="img-responsive" src="images/xpression/logo.png" alt="logo">
                            </a>                    
                        </div>
                        <div class="collapse navbar-collapse">
                            <ul class="nav navbar-nav navbar-right">                 
                                <li class="scroll active"><a href="#home">Home</a></li>
                                <li class="scroll"><a href="#explore">Explore</a></li>                         
                                <li class="scroll"><a href="#event">Event</a></li>
                                <li class="scroll"><a href="#about">About</a></li>                     
                                <li class="scroll"><a href="#gallery">Gallery</a></li>                     
                                <li class="scroll"><a href="#sponsor">Sponsers</a></li>
                                <li><a class="no-scroll" href="https://www.townscript.com/e/xpression17/booking" target="_blank">Register</a></li>
                                <li class="scroll"><a href="#contact">Contact</a></li>       
                            </ul>
                        </div>
                    </div>
                </div>
            </div>                    
        </header>
        <!--/#header--> 

        <section id="home">	
            <div id="main-slider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                    <li data-target="#main-slider" data-slide-to="1"></li>
                    <li data-target="#main-slider" data-slide-to="2"></li>
                    <li data-target="#main-slider" data-slide-to="3"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="item active">
                        <img class="img-responsive" src="images/xpression/slider/bg1.jpg" alt="slider">						
                        <div class="carousel-caption">
                            <h2>Event on 8 April </h2>
                            <h4>5.00 pm - 9.00 pm</h4>
                            <a href="https://www.townscript.com/e/xpression17/booking">REGISTER <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="images/xpression/slider/bg2.jpg" alt="slider">	
                        <div class="carousel-caption">
                            <h2>DRAMA, MUSIC, INTERNATIONAL ARTISTS PERFORMANCES </h2>

                            <a href="https://www.townscript.com/e/xpression17/booking">REGISTER  <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="images/xpression/slider/bg3.jpg" alt="slider">	
                        <div class="carousel-caption">
                            <h2>Venue ISKCON Kanpur</h2>

                            <a href="https://www.townscript.com/e/xpression17/booking" >Register<i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>	
                    <div class="item">
                        <img class="img-responsive" src="images/xpression/slider/bg4.jpg" alt="slider">	
                        <div class="carousel-caption">
                            <h2>Srila Prabhupada's 50th Anniversary</h2>

                            <a href="https://www.townscript.com/e/xpression17/booking" >Register<i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>    	
        </section>
        <!--/#home-->
        <!--<marquee behavior="alternate" align="center" onmouseover="this.stop();" onmouseout="this.start();"><a href="competition_update.php" target="_blank"><img src="./img/new.gif" height=30px><p><font size="5" color="strong white">Competition updates:Only for the registered candidates of Xpression</font></p></a></marquee>-->

        <section id="explore">
            <div class="container">
                <div class="row">
                    <div class="watch">
                        <img class="img-responsive" src="images/xpression/watch.png" alt="">
                    </div>				
                    <div class="col-md-4 col-md-offset-2 col-sm-5">
                        <h2>our next event in</h2>
                    </div>				
                    <div class="col-sm-7 col-md-6">					
                        <ul id="countdown">
                            <li>					
                                <span class="days time-font">00</span>
                                <p>days </p>
                            </li>
                            <li>
                                <span class="hours time-font">00</span>
                                <p class="">hours </p>
                            </li>
                            <li>
                                <span class="minutes time-font">00</span>
                                <p class="">minutes</p>
                            </li>
                            <li>
                                <span class="seconds time-font">00</span>
                                <p class="">seconds</p>
                            </li>				
                        </ul>
                    </div>
                </div>
                <div class="cart">
                    <a href="https://www.townscript.com/e/xpression17/booking"><i class="fa fa-shopping-cart"></i> <span>Purchase Tickets</span></a>
                </div>
            </div>
        </section><!--/#explore-->

        <section id="event">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-9">
                        <div id="event-carousel" class="carousel slide" data-interval="false">
                            <h2 class="heading">THE ROCKING Performers</h2>
                            <a class="even-control-left" href="#event-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                            <a class="even-control-right" href="#event-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event1.jpg" alt="event-image">
                                                <h4>Music Performance</h4>
                                                <h5>International Artist</h5>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event2.jpg" alt="event-image">
                                                <h4>Light Dance</h4>
                                                <h5>IIT Kharagpur</h5>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event3.jpg" alt="event-image">
                                                <h4>Celebrity</h4>
                                                <h5>Sajjan Jindal</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event1.jpg" alt="event-image">
                                                <h4>Music Performance</h4>
                                                <h5>International Artist</h5>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event2.jpg" alt="event-image">
                                                <h4>Light Dance</h4>
                                                <h5>IIT Kanpur</h5>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="single-event">
                                                <img class="img-responsive" src="images/xpression/event/event4.jpg" alt="event-image">
                                                <h4>Drama</h4>
                                                <h5>IIT BHU</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="padding-top: 165px" class="guitar">
                        <img class="img-responsive" src="images/xpression/guitar.png" alt="guitar">

                    </div>
                </div>			
            </div>
        </section><!--/#event-->

        <section id="about">
            <div class="guitar2">				
                    <!--<img class="img-responsive" src="images/xpression/guitar2.jpg" alt="guitar">-->
                <iframe style="margin-left: 64px;margin-top: 87px;" width="560" height="315" src="https://www.youtube.com/embed/QSYvRRG2SaM" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="about-content">					
                <h2>About Xpression</h2>
                <p>The main motto of the youth festival is to inspire the youth of India on leading a stress-free healthy lifestyle with practical techniques to manage mind and life through the joyful process of devotion, to gain focus on short-term and long-term goals of life. The youth festival will be a colorful combination of music, dance, drama and performances by an international team and delicious feast at the end.</p>
                <a href="#" class="btn btn-primary">View Date & Place <i class="fa fa-angle-right"></i></a>

            </div>
        </section><!--/#about-->

        <section id="gallery">

            <div id="gallery-carousel" class="carousel slide" data-interval="false">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <h2>Gallery</h2>	
                            <div class="container">
                                <br>
                                <!-- The container for the list of example images -->
                                <div id="links">
                                    <a href="images/xpression/gallery/gallery111.JPG" title="Xpression '17" data-gallery>
                                        <img src="images/xpression/gallery/gallery_small111.jpg" alt="Xpression '17">
                                    </a>
                                    <a href="images/xpression/gallery/gallery112.JPG" title="Xpression '17" data-gallery>
                                        <img src="images/xpression/gallery/gallery_small112.jpg" alt="Xpression '17">
                                    </a>
                                    <a href="images/xpression/gallery/gallery115.JPG" title="Xpression '17" data-gallery>
                                        <img src="images/xpression/gallery/gallery_small113.jpg" alt="Xpression '17">
                                    </a>
<!--                                    <a href="images/xpression/gallery/gallery114.JPG" title="Xpression '17" data-gallery>
                                        <img src="images/xpression/gallery/gallery_small114.png" alt="Xpression '17">
                                    </a>-->
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                                            <!--<a class="sponsor-control-left" href="#sponsor-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a>-->
                                            <!--<a class="sponsor-control-right" href="#sponsor-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a>-->
                            <!--                            <div class="carousel-inner">
                                                            <div class="item active">
                                                                <ul>
                                                                    <li><a href="#"><img class="img-responsive" src="images/xpression/gallery_small5.png" alt=""></a></li>
                                                                    <li><a href="#"><img class="img-responsive" src="images/xpression/gallery_small7.png" alt=""></a></li>
                                                                    <li><a href="#"><img class="img-responsive" src="images/xpression/gallery_small13.jpg" alt=""></a></li>
                                                                    <li><a href="#"><img class="img-responsive" src="images/xpression/gallery_small6.png" alt=""></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>-->
                        </div>
                    </div>	

                </div>
            </div>

        </section><!--/#sponsor-->

        <section id="sponsor">

            <div id="sponsor-carousel" class="carousel slide" data-interval="false">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-10">
                            <h2>Sponsors</h2>			
                            <a class="gallery-control-left" href="#gallery-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                            <a class="gallery-control-right" href="#gallery-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a>
                            <div class="carousel-inner">
                                <div class="item active">
                                  /*  <ul>
                                       <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor11.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor22.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor33.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor44.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor55.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor66.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor77.png" alt=""></a></li>

                                    </ul>
                                </div>
                                <div class="item">
                                    <ul>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor11.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor22.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor33.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor44.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor55.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor66.png" alt=""></a></li>
                                        <li><a href="#"><img class="img-responsive" src="images/xpression/sponsor77.png" alt=""></a></li>
                                    </ul>  */
                                </div>
                            </div>
                        </div>
                    </div>				
                </div>
                <div class="light">
                    <img class="img-responsive" src="images/xpression/light.png" alt="">
                </div>
            </div>
        </section><!--/#sponsor-->



        <section id="contact">
            <div id="map">
                <div id="gmap-wrap">
                    <div id="gmap"> 				
                    </div>	 			
                </div>
            </div><!--/#map-->
            <div class="contact-section">
                <div class="ear-piece">
                    <img class="img-responsive" src="images/xpression/ear-piece.png" alt="">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3 col-sm-offset-4">
                            <div class="contact-text">
                                <h3>Contact</h3>
                                <address>
                                    E-mail: info@iskconkanpur.com<br>
                                    Phone1: +91-7887219234<br>
                                    Phone2: +91-7887219235
                                </address>
                            </div>
                            <div class="contact-address">
                                <h3>Contact</h3>
                                <address>
                                    Sri Sri Radha Madhava Mandir,<br>
                                    Mainavati Marg, Bithoor Road,<br>
                                    Kanpur, Uttar Pradesh<br>
                                    208002
                                </address>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div id="contact-section">
                                <h3>Send a message</h3>
                                <div class="status alert alert-success" style="display: none"></div>
                                <form id="main-contact-form" class="contact-form" name="contact-form" method="post" action="sendemail.php">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" required="required" placeholder="Name">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" required="required" placeholder="Email ID">
                                    </div>
                                    <div class="form-group">
                                        <textarea name="message" id="message" required="required" class="form-control" rows="4" placeholder="Enter your message"></textarea>
                                    </div>                        
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary pull-right">Send</button>
                                    </div>
                                </form>	       
                            </div>
                        </div>
                    </div>
                </div>
            </div>		
        </section>
        <!--/#contact-->
        <!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
        <div id="blueimp-gallery" class="blueimp-gallery">
            <!-- The container for the modal slides -->
            <div class="slides">

            </div>
            <!-- Controls for the borderless lightbox -->
            <h3 class="title"></h3>
            <a class="prev">‹</a>
            <a class="next">›</a>
            <a class="close">×</a>
            <a class="play-pause"></a>
            <ol class="indicator"></ol>
            <!-- The modal dialog, which will be used to wrap the lightbox content -->
            <div class="modal fade">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" aria-hidden="true">&times;</button>
                            <h4 class="modal-title"></h4>
                        </div>
                        <div class="modal-body next"></div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left prev">
                                <i class="glyphicon glyphicon-chevron-left"></i>
                                Previous
                            </button>
                            <button type="button" class="btn btn-primary next">
                                Next
                                <i class="glyphicon glyphicon-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer id="footer">
            <div class="container">
                <div class="text-center">
                    <p> Copyright  &copy;2017<a target="_blank" href="http://iskconkanpur.com/xpression.php/"> Xpression </a> India. All Rights Reserved. <br> Designed by <a target="_blank" href="http://iskconkanpur.com/xpression.php">Expression Team</a></p>                
                </div>
            </div>
        </footer>
        <!--/#footer-->

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Bootstrap JS is not required, but included for the responsive demo navigation and button states -->
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="//blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
        <script type="text/javascript" src="js/xpression/bootstrap-image-gallery.js"></script>
        <script type="text/javascript" src="js/xpression/demo.js"></script>
        <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script type="text/javascript" src="js/xpression/gmaps.js"></script>
        <script type="text/javascript" src="js/xpression/smoothscroll.js"></script>
        <script type="text/javascript" src="js/xpression/jquery.parallax.js"></script>
        <script type="text/javascript" src="js/xpression/coundown-timer.js"></script>
        <script type="text/javascript" src="js/xpression/jquery.scrollTo.js"></script>
        <script type="text/javascript" src="js/xpression/jquery.nav.js"></script>
        <script type="text/javascript" src="js/xpression/main3.js"></script>  
        <script type="text/javascript">
//            $("#countdown").countdown({
//                date: "8/4/2017 17:00:00", // add the countdown's end date (i.e. 3 november 2012 12:00:00)
//                format: "d-m-y" // on (03:07:52) | off (3:7:52) - two_digits set to ON maintains layout consistency
//            });
        </script>
    </body>
</html>