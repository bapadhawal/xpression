<?php
	$amt_dict = array("1" => "130", "2" => "555",  "5" => "650", "6" => "750");
	$type = $_GET['type'];
	if($type == null){
		$type = "1";
	}
	try{
		$amt = $amt_dict[$type] * 100;
	}
	catch(Exception $e){
		$amt = 10000;
	}
	if($amt == null){
		$amt = 10000;
	}
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">


		<!-- Website CSS style -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<title>XPRESSION REGISTRATION PORTAL</title>
<style>
#playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
     height: 100%;
 	background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
	    background-size: cover;
}

.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=email], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    background-color: white;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<body>
<img src="assets/images/xpression.png" align="left" class= "img-responsive" >
<br><br><br>
<div>
<center><h1>Enter Your Details</h1></center>
</div>
<div>
<form action="make_payment.php" method="POST">
	<input type="hidden" value="<?php echo $amt; ?>" name="amount" />
	<input type="hidden" value="<?php echo $type; ?>" name="type" />
	
	<input type="text" id="username" name="username" placeholder="Name" required/><br/>
	<input type="email" id="email" name="email" placeholder="Email" required/><br/>
	<input type="text" id="contact" name="contact" placeholder="Contact Number" required/><br/>
	<input type="text" id="institution" name="institution" placeholder="Institution Name" required/><br/>	
							<select name="how" id="how">
						  <option selected disabled>What inspired you to register for Xpression'18 ?</option>
						  <option value="I attended Xpression Last time">I attended Xpression Last time</option>
						  <option value="pression team came to my college/school, I heard their announcement">Xpression team came to my college/school, I heard their announcement</option>
						  <option value="I saw a poster in college/school">I saw a poster in college/school</option>
						  <option value="I got a Leaflet with details about Xpression">I got a Leaflet with details about Xpression</option>
						  <option value="I saw an Ad in Newspaper">I saw an Ad in Newspaper</option>					
						  <option value="My friends told me about Xpression">My friends told me about Xpression</option>
						  <option value="I came to know from WhatsApp">I came to know from WhatsApp</option>
						  <option value="I saw a Poster in ISKCON temple">I saw a Poster in ISKCON temple</option>
						</select>
				<!-- </div> -->
	<input type="submit" value="Submit!"/><br/>
</form>
</div>
</body>
</html>
