<?php
	if(!isset($_POST)){
		die("Cannot proceed to pay!");
	}
	
	$amt = $_POST['amount'];
	$name = $_POST['username'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	$institution = $_POST['institution'];
	$type = $_POST['type'];	
    $how = $_POST['how'];
	
	if($amt == null || $name == null || $email == null || $contact == null){
		die("Cannot proceed to pay!");
	}
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">


		<!-- Website CSS style -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<style>
#playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
     height: 100%;
 	background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
	    background-size: cover;
}

.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=email], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}


input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<body>
<img src="assets/images/xpression.png" align="left" class= "img-responsive" >
<br><br><br>
<div>
<center><h1>Confirm Your Details to make Payment</h1></center>
</div>
<div>
<input type="text" id="username" name="username" value="<?php echo $name; ?>" disabled/><br/>
<input type="text" id="email" name="email" value="<?php echo $email; ?>" disabled/><br/>
<input type="text" id="contact" name="contact" value="<?php echo $contact; ?>" disabled/><br/>
<input type="text" id="institution" name="institution" value="<?php echo $institution; ?>" disabled/><br/>	
<input type="text" id="how" name="how" value="<?php echo $how; ?>" disabled/><br/>
</div>
<form action="/confirmation.php" method="POST">

<input type="hidden" value="<?php echo $amt; ?>" name="amount" />
<input type="hidden" value="<?php echo $type; ?>" name="type" />

<input type="hidden" id="username" name="username" value="<?php echo $name; ?>"/><br/>
<input type="hidden" id="email" name="email" value="<?php echo $email; ?>"/><br/>
<input type="hidden" id="contact" name="contact" value="<?php echo $contact; ?>"/><br/>
<input type="hidden" id="institution" name="institution" value="<?php echo $institution; ?>"/><br/>	
<input type="hidden" id="how" name="how" value="<?php echo $how; ?>" /><br/>

<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_live_ARYyzEQgBdfbyq"
    data-amount=<?php echo $amt?>
    data-buttontext="Proceed to pay!"
    data-name="Xpression 2018"
    data-description="Entry Ticket Purchase"
    data-image="/assets/images/xpression.png"
    data-prefill.name=<?php echo $name; ?>
    data-prefill.email=<?php echo $email; ?>
    data-prefill.contact=<?php echo $contact; ?>
    data-theme.color="#F37254"
></script>
</form>
</body>
</html>
